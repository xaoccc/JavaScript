function solve() {
    const rootUrl = 'http://localhost:3030/jsonstore/tasks/';
    const list = document.getElementById('list');
    const loadCourseBtn = document.getElementById('load-course');
    const addCourseBtn = document.getElementById('add-course');
    const editCourseBtn = document.getElementById('edit-course');
    const [title, type, description, teacher] = document.querySelectorAll('#form input, #form textarea')

    function createChild(tag, parent, classes, text, id) {
        let listItem = document.createElement(tag);
        parent.appendChild(listItem);
        (classes) ? listItem.classList.add(...classes) : null;
        (text) ? listItem.textContent = text : null;
        (id) ? listItem.id = id : null;
        return listItem;
    }

    async function loadCourses() {
        list.innerHTML = '';
        await fetch(rootUrl)
        .then((res) => res.json())
        .then((data) => {

            for (id in data) {
                const container = createChild('div', list, ['container'], '', id);
                createChild('h2', container, [], data[id].title);
                createChild('h3', container, [], data[id].teacher);
                createChild('h3', container, [], data[id].type);
                createChild('h4', container, [], data[id].description);
                const editCourseBtn = createChild('button', container, ['edit-btn'], 'Edit Course');
                const finishCourseBtn =createChild('button', container, ['finish-btn'], 'Finish Course');
                editCourseBtn.addEventListener('click', async (e) => editCourse(e));
                finishCourseBtn.addEventListener('click', async (e) => finishCourse(e));
            }
        })
        .catch((error) => console.log(error));
    }

    async function addCourse() {
        await fetch(rootUrl, {
            method: 'POST',
            body: JSON.stringify({
                title: title.value,
                type: type.value,
                description: description.value,
                teacher: teacher.value
            })
        })
        .catch((error) => console.log(error));
        [title, type, description, teacher].forEach((input) => input.value = '');
        await loadCourses();
    }

    async function finishCourse(e) {
        const id = e.target.parentElement.id;
        e.target.parentElement.remove();
        await fetch(`${rootUrl}${id}`, {
            method: 'DELETE'
        })
        .catch((error) => console.log(error));
        await loadCourses();
    }

    function editCourse(e) {
        const id = e.target.parentElement.id;
        const current = Array.from(e.target.parentElement.children).slice(0, -2);
        [title, teacher, type, description].forEach((input, i) => input.value = current[i].textContent);
        title.parentElement.id = id;
        addCourseBtn.disabled = true;
        editCourseBtn.disabled = false;       
    }

    loadCourseBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        await loadCourses();        
    })

    addCourseBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        await addCourse();
    })
    editCourseBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        id = e.target.parentElement.id
        await fetch(`${rootUrl}${id}`, {
            method: 'PUT',
            body: JSON.stringify({
                title: title.value,
                type: type.value,
                description: description.value,
                teacher: teacher.value,
                _id: id
            })
        })
        .catch((error) => console.log(error));
        await loadCourses();
        [title, type, description, teacher].forEach((input) => input.value = '');
        addCourseBtn.disabled = false;
        editCourseBtn.disabled = true;  
        e.target.parentElement.id = '';          
    }) 

}

solve();